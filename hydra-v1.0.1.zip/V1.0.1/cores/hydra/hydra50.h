/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */

#ifndef __HYDRA50_H__
#define __HYDRA50_H__
//#include <Arduino.h>

//ham dung trong ctrinh
void hardwareIO();

uint8_t digitalInput(uint8_t channelNumber);
/*
channelNumber from 0 - 15 of digital input channels
return value of this function is signal of input channel = LOW or HIGH
*/

//void digitalOutput(uint8_t chanelNumber, uint8_t valToWrite); //chuyen qua khai bao o arduino.h line 134

/*
channel number from 1 to 16 with switch on/off DOs and feedback of status
channel number from 17 to 24 with switch ON/OFF and feedback of current sense & status
*/
/*
function to do PWM on output channels 0-9
*/
void pwmOutput(uint8_t channelNumber, float value);

uint16_t analogInput(uint16_t channelNumber);
uint16_t digitalOutCurrentSense(uint8_t channelNumber); //function to read current sense of digital out channels from 17 - 24

//ham doc status of DOs
uint8_t statusDigitalOutput(uint8_t channelNo);

#endif