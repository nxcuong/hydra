/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */


#ifndef __HYDRA_H__
#define __HYDRA_H__

#include "Arduino.h"
void hydraInitDefault();
#endif