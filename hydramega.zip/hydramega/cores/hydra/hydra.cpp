
#include "hydra.h"
					  
//==========================================initiation of Hydra board =========================
void hydraInitDefault() {
#if defined(HYDRAMEGA_50) 
	pinMode(stAuxRelay, INPUT); //status of axiliary relay
	pinMode(CAN1INT, INPUT); //CAN1 interrupt
	pinMode(CAN2INT, INPUT); //CAN2 interrupt
	//status of digital output channels from 0 -15
	pinMode(stDO1, INPUT);
	pinMode(stDO3, INPUT);
	pinMode(stDO5, INPUT);
	pinMode(stDO7, INPUT);
	pinMode(stDO9, INPUT);
	pinMode(stD11, INPUT);
	pinMode(stD13, INPUT);
	pinMode(stD15, INPUT);
	//status of PWM channels 0 - 9
	pinMode(stPWM0, INPUT);
	pinMode(stPWM1, INPUT);
	pinMode(stPWM2, INPUT);
	pinMode(stPWM3, INPUT);
	pinMode(stPWM4, INPUT);
	pinMode(stPWM5, INPUT);
	pinMode(stPWM6, INPUT);
	pinMode(stPWM7, INPUT);
	pinMode(stPWM8, INPUT);
	pinMode(stPWM9, INPUT);
	//current sense of 8DO channels from 16 to 23, analog input to A0-A7
	pinMode(iSenseDO24, INPUT);
	pinMode(iSenseDO17, INPUT);
	pinMode(iSenseDO18, INPUT);
	pinMode(iSenseDO19, INPUT);
	pinMode(iSenseDO20, INPUT);
	pinMode(iSenseDO21, INPUT);
	pinMode(iSenseDO22, INPUT);
	pinMode(iSenseDO23, INPUT);
	//===================================================================
	//digital output config
	pinMode(mainSwitch, OUTPUT);//main switch mosfet
	pinMode(IOCS0, OUTPUT);
	pinMode(IOCS1, OUTPUT);
	pinMode(IOCS2, OUTPUT);
	pinMode(ADCCS1, OUTPUT);
	pinMode(ADCCS2, OUTPUT);
	pinMode(CANCS1, OUTPUT);
	pinMode(CANCS2, OUTPUT);
	//gate control of 10 channels pwm fet
	pinMode(gatePWM0, OUTPUT);
	pinMode(gatePWM1, OUTPUT);
	pinMode(gatePWM2, OUTPUT);
	pinMode(gatePWM3, OUTPUT);
	pinMode(gatePWM4, OUTPUT);
	pinMode(gatePWM5, OUTPUT);
	pinMode(gatePWM6, OUTPUT);
	pinMode(gatePWM7, OUTPUT);
	pinMode(gatePWM8, OUTPUT);
	pinMode(gatePWM9, OUTPUT);

	//set all output channels to 0 at beginning
	digitalWrite(mainSwitch, LOW);
	//pwmOutput(0, 0);

	
#endif
	//===============================================================================Timer setting for PWM out
	//we use TIMER 3, 4, 5
	//Timer 3 setting
	
	TCCR3A = 0x00; //clear registers
	TCCR3B = 0x00;
	OCR3A = 0;
	OCR3B = 0;
	OCR3C = 0;
	//setting registers
	TCCR3A |= _BV(COM3A1) | _BV(COM3B1) | _BV(COM3C1) | _BV(WGM31);
	TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS30); //mode 14, prescale = 1;
	ICR3 = 5710; // frequency of pwm out = fclk/N.(1+TOP) = 16 000 000 / 1.(1+5710) = 16000000/5711 = 2.8kHz

	//Timer 4 setting
	TCCR4A = 0x00; //clear registers
	TCCR4B = 0x00;
	OCR4A = 0; //clear outputs
	OCR4B = 0;
	OCR4C = 0;
	//setting registers
	TCCR4A |= _BV(COM4A1) | _BV(COM4B1) | _BV(COM4C1) | _BV(WGM41);
	TCCR4B |= _BV(WGM43) | _BV(WGM42) | _BV(CS40); //mode 14, prescale = 1;
	ICR4 = 5710;

	//Timer 5 setting
	TCCR5A = 0x00; //clear registers
	TCCR5B = 0x00;
	OCR5A = 0;
	OCR5B = 0;
	OCR5C = 0;
	//setting registers
	TCCR5A |= _BV(COM5A1) | _BV(COM5B1) | _BV(COM5C1) | _BV(WGM51);
	TCCR5B |= _BV(WGM53) | _BV(WGM52) | _BV(CS50); //mode 14, prescale = 1;
	ICR5 = 5710;
	
	//====================================================================end of Timer settings
}
/*
void hardwareIO() //use in hydra50.cpp
{
	//switch off main
	digitalWrite(mainSwitch, LOW);
	//====================================================================initiation of digital inputs

	iochip0.begin(); //16 channels of 24VDI no.0 to no.15
	iochip1.begin(); //8DOs channels of gate firer I_HSW 1-8, 8DIs of status 9 - 16
	iochip2.begin(); //16 DOs of gate fire PSW 1 - 16
	adc1.begin(); //start of ADC1 and 2
	adc2.begin();
	iochip0.pinMode(0B1111111111111111); //all DIs, 1 as input, 0 as output
	iochip1.pinMode(0B1111111100000000); //8DOs 8 DIs
	iochip2.pinMode(0B0000000000000000); // all DOs
	//=================== end of IO chip pinmode
	//test do on io chip
	//iochip1.digitalWrite(0B0000000000000000);
	iochip2.digitalWrite(0B0000000000000000);
	for (int i = 1; i <= 8; i++) {
		iochip1.digitalWrite(i, LOW);

	}//end of di, do initiation

}//END OF HARDWARE IO FUNC=======================================================================
*/
