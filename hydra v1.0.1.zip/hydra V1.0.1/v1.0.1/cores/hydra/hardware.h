/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */
#include <Arduino.h>
#include <hydra.h>

#ifndef hardware_h
#define hardware_h

#define __IOCHIP0__
#define __IOCHIP1__
#define __IOCHIP2__
#define __ADC1__
#define __ADC2__
#endif
void hardwareIO();
uint8_t digitalInput(uint8_t channelNumber);
/*
channelNumber from 0 - 15 of digital input channels
return value of this function is signal of input channel = LOW or HIGH
*/

void digitalOutput(uint8_t chanelNumber, uint8_t valToWrite);
void digitalOutput(int channelNumber, int valueToWite);
/*
channel number from 1 to 16 with switch on/off DOs and feedback of status
channel number from 17 to 24 with switch ON/OFF and feedback of current sense & status
*/

uint16_t analogInput(uint16_t channelNumber);
uint16_t digitalOutCurrentSense(uint8_t channelNumber); //function to read current sense of digital out channels from 17 - 24

//ham doc status of DOs
uint8_t statusDigitalOutput(uint8_t channelNo);