/*
chu y:
Viec khoi tao doi voi mcp3208 va mcp23s17 phai duoc thuc hien !
Cac ham thu vien nay phai duoc copy vao trong thu muc cores! neu khong se bao loi!

nhu vay main.cpp chi tham chieu den cac ham trong thu muc cores va mot so file thu vien noi bo.
khong tham chieu den cac file thu vien trong thu muc libraries
*/

#include <Arduino.h>
#include "hydra.h"
#include <pins_arduino.h>
#include "hardware.h"

#include <MCP23S17.h>
#include <MCP3208.h>

MCP iochip0(0, IOCS0); //16DIs
MCP iochip1(1, IOCS1); //8DOs isense, 8DOs status
MCP iochip2(2, IOCS2); //16DOs
//ADC 1 and 2
MCP3208 adc1(ADCCS1); //isense from 1 - 8
MCP3208 adc2(ADCCS2); // isense from 9- 10 and analog in 1 - 6

//test thu khai bao mang cho DIs
//uint16_t diIN[16];
					  
//==========================================initiation of Hydra board =========================

void hardwareIO() 
{	
	//switch off main
	digitalWrite(mainSwitch, LOW);
	//====================================================================initiation of digital inputs
	
	iochip0.begin(); //16 channels of 24VDI no.0 to no.15
	iochip1.begin(); //8DOs channels of gate firer I_HSW 1-8, 8DIs of status 9 - 16
	iochip2.begin(); //16 DOs of gate fire PSW 1 - 16
	adc1.begin(); //start of ADC1 and 2
	adc2.begin();
	iochip0.pinMode(0B1111111111111111); //all DIs, 1 as input, 0 as output
	iochip1.pinMode(0B1111111100000000); //8DOs 8 DIs
	iochip2.pinMode(0B0000000000000000); // all DOs
	//=================== end of IO chip pinmode
	//test do on io chip
	//iochip1.digitalWrite(0B0000000000000000);
	iochip2.digitalWrite(0B0000000000000000);
	for (int i = 1; i <= 8; i++) {
		iochip1.digitalWrite(i, LOW);

	}//end of di, do initiation

}//END OF HARDWARE IO FUNC=======================================================================


//fucntion of DI, DO

uint8_t digitalInput(uint8_t channelNumber){
	//channel must be from 0 - 15,
	
//#if defined(iochip0)
	uint8_t i = channelNumber;
	uint8_t value;
	if ((i > 0) && (i <= 16)) {
		//do reading channels here!
		
		value = iochip0.digitalRead(i);
		return value;
	}
	else
	{
		return 0;
	}
//#else
	//return 0;
//#endif // 
}//end of digialInput func==================================

void digitalOutput(int channelNumber, int valueToWite) {
	//digital out from no.0 to 15
	int i = channelNumber;
	int value = valueToWite;
	if ((i > 0) && (i <= 16)) {
		//channels in range 0-15
		//check value 0 or 1
		if ((value >= 0) && (value <= 1)) {
			iochip2.digitalWrite(i, value);
		}
	}
	else if ((i > 16) && (i < 25)) {
			//channels output from 16 to 23 of iochip1
		int j = i - 16;
		if ((value >= 0) && (value <= 1)) {
				iochip1.digitalWrite(j, value);
		}
	}
}

//=============================================================================================
//function of ADC read!
uint16_t analogInput(uint16_t channelNumber) {
	//analog channels corresponding from 0-15
	//ana0-ana9 <=> current sense of IPWM0-IPWM9
	//ana0-7 come to adc1.0-7
	//ana8-9 come to adc2.0-1
	//ana10-15 <> to adc2.3-7
	uint16_t i = channelNumber;
	uint16_t anaValue;
	if (i <= 15)
	{
		//i in range 0-15
		if (i <= 7)
		{
			//i from 0-7
			//read adc1
			anaValue = adc1.analogRead(i);
			//return anaValue;
		}
		else if(i==8)
		{
				//adc2.0
				anaValue = adc2.analogRead(0);
		}
		else if(i==9)
		{
			anaValue = adc2.analogRead(1);
		}
		else if ((i > 9) && (i < 16))
		{
			//analog channels on X4
			uint8_t j = i - 8;
			anaValue = adc2.analogRead(j);
		}
		return anaValue;
	}
	else {
		return 0;
	}
	
}
//
uint16_t digitalOutCurrentSense(uint8_t channelNumber) {
	//current sense of DOs 17-23
	return 0; //test
}

uint8_t statusDigitalOutput(uint8_t channelNo) {
	uint8_t i = channelNo;
	uint8_t value = digitalRead(i);
	return value;
}